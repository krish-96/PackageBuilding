class PackageBuildingException(Exception):
    """This exception is raised whenever there is an error in this package"""
